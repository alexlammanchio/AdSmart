<?php include('../config/constants.php');?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>AdSmart | Ecommerce Platform</title>
<link href="css/style-admin.css" rel="stylesheet" />
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
</head>
<body>
<div class="navbar">
    <nav>
      <input type="checkbox" id="show-search">
      <input type="checkbox" id="show-menu">
      <label for="show-menu" class="menu-icon"><i class="fas fa-bars"></i></label>
      <div class="content">
      <div class="logo"><a href="#"><img src="images/AdSmart_logo.png" style="width:60px; height:60px;"></a></div>
      <div class="logo"><a href="#">ADSMART</a></div>
        <ul class="links">
	         <li><a href="index.php" >Home</a></li>
	         <li><a href="manage-admin.php" >Admin</a></li>	         
	          <li><a href="manage-category.php" >Category</a></li>
	          <li><a href="logout.php" >logout</a></li>         
        </ul>
      </div>
     </nav>
  </div>
	    <!-- Menu Section Ends -->