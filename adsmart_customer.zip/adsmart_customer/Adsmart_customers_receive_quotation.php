 <?php  include('../partials-front/after_customer_login_menu.php');?>
<div style="background:#1b0075">
               <?php  include('../partials-front/customer_left_bar.php');?>


              <div class='container-fluid'>
            	   	<div class='reg' style='width: 1000px; margin-top:100px;'>
		<div class="reg">		
		<?php
		$id =$_GET['id'];
		$sql2 = "SELECT * from qoutation where id = '$id'";
		$res2 = mysqli_query($conn, $sql2);
		$row2 = mysqli_fetch_array($res2);
		$req_number =$row2['req_number'];
		Echo "<h1>Advertisement Request - Ticket: <b style ='text-transform: uppercase;'> ".$req_number."</b> </h1>";  
    		?>
    		<div class="reg-container">	
					          <form action="handle_customer_receive_quotation.php" method="POST" enctype="multipart/form-data">
					            <table >
											<tbody>
												<tr>
												     <tH colspan="2" style="text-align:center; background:#9198e5">Advertisement Request Detail</th>
												</tr>
												<tr>
												    <td colspan="2" >
												    
												    <?php 
												            $id=$_GET['id'];
												           
													    	$sql1 = "SELECT *, a.id as req_no,
                                                             case budget 
                                                                WHEN 1 Then 'Less Than \$HK 5000'
                                                                WHEN 2 Then 'Less Than \$HK 10000'
                                                                WHEN 3 Then 'Great Than \$HK 10000 and Less Than \$HK 50000'
                                                                WHEN 4 Then 'Great Than \$HK 50000 and Less Than \$HK 200000'
                                                                WHEN 5 Then 'No Budget Limited'
                                                                End as budget_name
                                                             from qoutation as a 
                                                            inner join adsmart_customer as b on a.customer_name=b.user_id
                                                            where a.id = '$id'";
													    	$res1 = mysqli_query($conn, $sql1);
													    	$row = mysqli_fetch_array($res1);
													    	$id = $row['req_no'];
													    	$customer_name =$row['customer_name'];
													    	$email = $row['email'];
													    	$requiremnt =$row['requirement'];
													    	$budget= $row['budget_name'];
													    	$deadline_date = $row['deadline_date'];
													    	$type_id = $row['category_id'];
													       $company_name = $row['company_name'];
													          $company_country = $row['company_country'];
													          $department_name =$row['department_name'];
													          $title =$row['title'];
													          $work_number = $row['work_number'];
													       $ticket_number = $row['req_number'];
													       $product_name = $row['product_name'];
													       $contact_number =$row['contact_number'];
													   $sql2 = "SELECT *
                                                             from adsmart_category where id = '$type_id'";
													   $res2 = mysqli_query($conn, $sql2);
													   $row2 = mysqli_fetch_array($res2);
													   if(isset($row2['display_name'])){ $type=$row2['display_name'];}
													   else{$type ='';};
													   if(isset($row2['display_name'])){
													       $category_name =$row2['display_name'];}
													       else{
													           
													           $category_name='';
													       }
													       
													   ?> 	
													    	
													   <fieldset style="padding-left:15px;"><legend>Requetor's basic information</legend>
												      <br>
												      	
												    	<div id="customer_name">
												    	
													    	
													    	
													    	
													    <?php 
													    echo "<input type='hidden' value='".$customer_name."' name='customer_name' readonly style='color:Green; font-size: 16px; width:450px;height:30px; font-weight:bold; border: 2px solid black;'>";
													    echo "<p style='text-transform:none; font-size:18px;'><strong style='color:blue;' >Customer Name: </strong> ".$customer_name."</p>";
													    	 
													    	
													    	?>
													    	
													  
													    	
													    	<br>
													    
													    </div>		
													    <div id="Contact_number">
												    	
													    
													    	
													    	 <?php 
													    	 echo "<p style='text-transform:none; font-size:18px;'><strong style='color:blue;'>Contact Number: </strong>".$contact_number."</p>";
													   
													    	 
													    	
													    	?>
													    	
													    	
													    	
													    
													    <br>
													    </div>											    
													    
													    <div id="email">
												    	
													    
													    	
													    	<?php 
													    	echo "<input type='hidden' value='".$email."' name='email' readonly style='color:Green; font-size: 16px; width:450px;height:30px; font-weight:bold; border: 2px solid black;'>";
													    	echo "<p style='text-transform:none; font-size:18px;'><strong style='color:blue;' >Email: </strong> ".$email."</p>";
													    	
													    	?>
													    	
													    	
													    	<br>
													    	
													    <br>
													    
													   </fieldset>
													   <br>
													    <fieldset style="padding-left:15px;"><legend>Ticket's information</legend>
												      <br>
												      <div id="customer_id">
												    	
													    	
													    	
													    <?php 
													    echo "<input type='hidden' value='".$ticket_number."' name='ticket_id' readonly style=' color:Green; font-size: 16px; width:450px;height:30px; font-weight:bold;border: 2px solid black;'>";
													    echo "<p style='text-transform:none; font-size:18px;'><strong style='color:blue;' >Ticket Name:</strong> ".$ticket_number."</p>";		
													    
													    
													    ?>
													    	
													    	
													    	
													  
													    	
													    	<br>
													    
													    </div>	
													    <div id="type">
												    	
													    	
													    	
													    	<?php if(!empty($type)){													      
                                                       
													        echo "<p style='text-transform:none; font-size:18px;'><strong style='color:blue;' >Advertisement Type:</strong> ".$type."</p>";														      
													        echo "<br>";
													        
													        
													    }
													    elseif(!empty($product_name)){
													        
													        echo "<p style='text-transform:none; font-size:18px;'><strong style='color:blue;' >Product Name:</strong> ".$product_name."</p>";
													        echo "<br>";
													        
													    } ?>
													   
													    
													    	
													    	
													  
													    	
													  
													    
													    </div>	
												      <div id="req">
												    	
													    	<p style='text-transform:none; font-size:18px;'><strong style='color:blue;' >Advertisement Requirement:</strong></p>
													    	<script src="tinymce/tinymce.min.js">

                                                            </script>
                                                            <script>
                                                            
                                                            tinymce.init({
                                                                selector: '#myTextarea',   
                                                                readonly: true,
                                                                image_advtab: true,
                                                                link_list: [
                                                                  { title: 'My page 1', value: 'https://www.codexworld.com' },
                                                                  { title: 'My page 2', value: 'http://www.codexqa.com' }
                                                                ],
                                                                image_list: [
                                                                  { title: 'My page 1', value: 'https://www.codexworld.com' },
                                                                  { title: 'My page 2', value: 'http://www.codexqa.com' }
                                                                ],
                                                                image_class_list: [
                                                                  { title: 'None', value: '' },
                                                                  { title: 'Some class', value: 'class-name' }
                                                                ],
                                                                importcss_append: true,
                                                                file_picker_callback: (callback, value, meta) => {
                                                                  /* Provide file and text for the link dialog */
                                                                  if (meta.filetype === 'file') {
                                                                    callback('https://www.google.com/logos/google.jpg', { text: 'My text' });
                                                                  }
                                                              
                                                                  /* Provide image and alt text for the image dialog */
                                                                  if (meta.filetype === 'image') {
                                                                    callback('https://www.google.com/logos/google.jpg', { alt: 'My alt text' });
                                                                  }
                                                              
                                                                  /* Provide alternative source and posted for the media dialog */
                                                                  if (meta.filetype === 'media') {
                                                                    callback('movie.mp4', { source2: 'alt.ogg', poster: 'https://www.google.com/logos/google.jpg' });
                                                                  }
                                                                },
                                                                
                                                                height: 400,
                                                                image_caption: true,
                                                               
                                                                content_style: 'body { font-family:Helvetica,Arial,sans-serif; font-size:16px }'
                                                            });

                                                            tinymce.init({
                                                                selector: '#myTextarea1',   
                                                                readonly: true,
                                                                image_advtab: true,
                                                                link_list: [
                                                                  { title: 'My page 1', value: 'https://www.codexworld.com' },
                                                                  { title: 'My page 2', value: 'http://www.codexqa.com' }
                                                                ],
                                                                image_list: [
                                                                  { title: 'My page 1', value: 'https://www.codexworld.com' },
                                                                  { title: 'My page 2', value: 'http://www.codexqa.com' }
                                                                ],
                                                                image_class_list: [
                                                                  { title: 'None', value: '' },
                                                                  { title: 'Some class', value: 'class-name' }
                                                                ],
                                                                importcss_append: true,
                                                                file_picker_callback: (callback, value, meta) => {
                                                                  /* Provide file and text for the link dialog */
                                                                  if (meta.filetype === 'file') {
                                                                    callback('https://www.google.com/logos/google.jpg', { text: 'My text' });
                                                                  }
                                                              
                                                                  /* Provide image and alt text for the image dialog */
                                                                  if (meta.filetype === 'image') {
                                                                    callback('https://www.google.com/logos/google.jpg', { alt: 'My alt text' });
                                                                  }
                                                              
                                                                  /* Provide alternative source and posted for the media dialog */
                                                                  if (meta.filetype === 'media') {
                                                                    callback('movie.mp4', { source2: 'alt.ogg', poster: 'https://www.google.com/logos/google.jpg' });
                                                                  }
                                                                },
                                                                
                                                                height: 400,
                                                                image_caption: true,
                                                               
                                                                content_style: 'body { font-family:Helvetica,Arial,sans-serif; font-size:16px }'
                                                            });

                                                            tinymce.init({
                                                                selector: '#myTextarea2',
                                                                plugins: 'preview importcss searchreplace autolink autosave save directionality code visualblocks visualchars fullscreen image link media template codesample table charmap pagebreak nonbreaking anchor insertdatetime advlist lists wordcount help charmap quickbars emoticons',
                                                                menubar: 'file edit view insert format tools table help',
                                                                toolbar: 'undo redo | bold italic underline strikethrough | fontfamily fontsize blocks | alignleft aligncenter alignright alignjustify | outdent indent |  numlist bullist | forecolor backcolor removeformat | pagebreak | charmap emoticons | fullscreen  preview save print | insertfile image media template link anchor codesample | ltr rtl',
                                                                toolbar_sticky: true,
                                                                autosave_ask_before_unload: true,
                                                                autosave_interval: '30s',
                                                                autosave_prefix: '{path}{query}-{id}-',
                                                                autosave_restore_when_empty: false,
                                                                autosave_retention: '2m',
                                                                image_advtab: true,
                                                                link_list: [
                                                                  { title: 'My page 1', value: 'https://www.codexworld.com' },
                                                                  { title: 'My page 2', value: 'http://www.codexqa.com' }
                                                                ],
                                                                image_list: [
                                                                  { title: 'My page 1', value: 'https://www.codexworld.com' },
                                                                  { title: 'My page 2', value: 'http://www.codexqa.com' }
                                                                ],
                                                                image_class_list: [
                                                                  { title: 'None', value: '' },
                                                                  { title: 'Some class', value: 'class-name' }
                                                                ],
                                                                importcss_append: true,
                                                                file_picker_callback: (callback, value, meta) => {
                                                                  /* Provide file and text for the link dialog */
                                                                  if (meta.filetype === 'file') {
                                                                    callback('https://www.google.com/logos/google.jpg', { text: 'My text' });
                                                                  }
                                                              
                                                                  /* Provide image and alt text for the image dialog */
                                                                  if (meta.filetype === 'image') {
                                                                    callback('https://www.google.com/logos/google.jpg', { alt: 'My alt text' });
                                                                  }
                                                              
                                                                  /* Provide alternative source and posted for the media dialog */
                                                                  if (meta.filetype === 'media') {
                                                                    callback('movie.mp4', { source2: 'alt.ogg', poster: 'https://www.google.com/logos/google.jpg' });
                                                                  }
                                                                },
                                                                templates: [
                                                                  { title: 'New Table', description: 'creates a new table', content: '<div class="mceTmpl"><table width="98%%"  border="0" cellspacing="0" cellpadding="0"><tr><th scope="col"> </th><th scope="col"> </th></tr><tr><td> </td><td> </td></tr></table></div>' },
                                                                  { title: 'Starting my story', description: 'A cure for writers block', content: 'Once upon a time...' },
                                                                  { title: 'New list with dates', description: 'New List with dates', content: '<div class="mceTmpl"><span class="cdate">cdate</span><br><span class="mdate">mdate</span><h2>My List</h2><ul><li></li><li></li></ul></div>' }
                                                                ],
                                                                template_cdate_format: '[Date Created (CDATE): %m/%d/%Y : %H:%M:%S]',
                                                                template_mdate_format: '[Date Modified (MDATE): %m/%d/%Y : %H:%M:%S]',
                                                                height: 400,
                                                                image_caption: true,
                                                                quickbars_selection_toolbar: 'bold italic | quicklink h2 h3 blockquote quickimage quicktable',
                                                                noneditable_class: 'mceNonEditable',
                                                                toolbar_mode: 'sliding',
                                                                contextmenu: 'link image table',
                                                                content_style: 'body { font-family:Helvetica,Arial,sans-serif; font-size:16px }'
                                                            });
                                                            </script>
													    
													   
													    <?php echo "<textarea  id ='myTextarea' name='requirement'>".$requiremnt."</textarea>"; ?>
													    
													    
												
													    	
													    	
													    	
													  
													    	
													    	<br>
													    
													    </div>		
												    	<div id="budget">
												    	
													    
													    	
													    	
													    <?php 
													    echo "<input type='hidden' value='".$budget."' name='budget' readonly style='color:Green; font-size: 16px; width:450px;height:30px; font-weight:bold; border: 2px solid black;'>";
													   
													    echo "<p style='text-transform:none; font-size:18px;'><strong style='color:blue;' >Budget:</strong> ".$budget."</p>";		
													    	
													    	?>
													    	
													  
													    	
													    	<br>
													    
													    </div>		
													    											    
													    
													    <div id="email">
												    	
													    	
													    	
													    	<?php 
													    	echo "<input type='hidden' value='".$deadline_date."' name='deadline_date' readonly style='color:Green; font-size: 16px; width:450px;height:30px; font-weight:bold; border: 2px solid black;'>";
													    	echo "<p style='text-transform:none; font-size:18px;'><strong style='color:blue;' >Deadline Date:</strong> ".$deadline_date."</p>";		
													    	
													    	?>
													    	
													    	
													    	<br>
													    	
													    <br>
													    </div>
													   </fieldset>
													    <br>
												    	<fieldset style="padding-left:15px;"><legend>Company's information</legend>
												    	  <br>
												    	<?php 
												    	$id=$_GET['id'];
												    	$sql3 = "SELECT *
                                                             from qoutation a
                                                             inner join adsmart_business_partner b 
                                                             on a.company_id = b.shop_code
                                                             where a.id = '$id'";
												    	$res3 = mysqli_query($conn, $sql3);
												    	$row3 = mysqli_fetch_array($res3);
												    	$account_name =$row3['user_id'];
												    	$company_name =$row3['company_name'];
												    	$company_reg_number =$row3['company_reg_number'];												    	
												    	$company_reg_address =$row3['company_reg_address'];
												    	$company_email =$row3['email'];
												    	$country = $row3['country'];
												    	$shop_code =$row3['shop_code'];
												    	$implementation= $row3['implementation_plan'];
												    	$price= $row3['company_price'];
												    	$target_date =$row3['target_date'];
												    	$company_bid_time = $row3['company_bid_time'];
												    	?>
												    	<div id="company_id">												    	
													  
													    	
													    <?php 
													    echo "<input type='hidden' value='".$shop_code."' name='company_id' readonly style=' color:Green; font-size: 16px; width:250px;height:30px; font-weight:bold;border: 2px solid black;'>";
													    
													  	
													    
													    ?>
													    	
													    	
													    	
													  
													    	
													  
													    
													    </div>		
												    	<div id="company_name">
													    	
													    	
													    <?php 
													    echo "<input type='hidden' value='".$company_name."' name='company_name' readonly style='color:Green; font-size: 16px; width:450px;height:30px; font-weight:bold; border: 2px solid black;'>";
													    echo "<p style='text-transform:none; font-size:18px;'><strong style='color:blue;' >Comapny Name: </strong> ".$company_name."</p>";		
													    ?>
													    	<br>
													    </div>		
												    	<div id="company_email">
													    	
													    	
													    <?php 
													    echo "<input type='hidden' value='".$company_email."' name='company_email' readonly style='color:Green; font-size: 16px; width:450px;height:30px; font-weight:bold; border: 2px solid black;'>";
													    echo "<p style='text-transform:none; font-size:18px;'><strong style='color:blue;' >Company Email:</strong> ".$company_email."</p>";		
													    
													    ?>
													    	<br>
													    </div>	
													    <div id="company_reg_number">
													    	
													    	
													    <?php 
													    echo "<input type='hidden' value='".$company_reg_number."' name='company_reg_number' readonly style='color:Green; font-size: 16px; width:450px;height:30px; font-weight:bold; border: 2px solid black;'>";
													    echo "<p style='text-transform:none; font-size:18px;'><strong style='color:blue;' >Company Registration Number:</strong> ".$company_reg_number."</p>";		
													    
													    ?>
													    	<br>
													    </div>
													    
													    <div id="company_reg_address">
													    	
													    	
													    <?php 
													    echo "<input type='hidden' value='".$company_reg_address."' name='company_reg_address' readonly style='color:Green; font-size: 16px; width:450px;height:30px; font-weight:bold; border: 2px solid black;'>";
													    echo "<p style='text-transform:none; font-size:18px;'><strong style='color:blue;' >Company Registration Address:</strong> ".$company_reg_address."</p>";		
													    ?>
													    	<br>
													    </div>			
													    <div id="company_reg_address">
													    	
													    	
													    <?php 
													    echo "<input type='hidden' value='".$country."' name='country' readonly style='color:Green; font-size: 16px; width:450px;height:30px; font-weight:bold; border: 2px solid black;'>";
													    echo "<p style='text-transform:none; font-size:18px;'><strong style='color:blue;' >Country:</strong> ".$country."</p>";
													    
													    ?>
													    	<br>
													    </div>		
												    	<div id="requirement">
												    	
													    	<p style='text-transform:none; font-size:18px;'><strong style='color:blue;' >Implementation Plan:</strong></p>
													    	<?php 
													    	echo "<textarea  id='myTextarea1'  name='implementation' rows='14' cols='65' readonly>";
													    	  echo $implementation;
													    	echo "</textarea>";
													    	?>
													    	<br>
												    	</div>		
												    	<BR>
												    	
													    <div class="input-group">
													    	
													    		 <?php 
													    echo "<input type='hidden' value='".$price."' name='Price' readonly style='color:Green; font-size: 16px; width:450px;height:30px; font-weight:bold; border: 2px solid black;'>";
													    echo "<p style='text-transform:none; font-size:18px;'><strong style='color:blue;' >Price:</strong> ".$price."</p>";
													    
													    ?>
													    		<br>
													    		</div>
												    	
												    	<div class="input-group">
													    	
													    	 <?php 
													    echo "<input type='hidden' value='".$target_date."' name='Target Date' readonly style='color:Green; font-size: 16px; width:450px;height:30px; font-weight:bold; border: 2px solid black;'>";
													    echo "<p style='text-transform:none; font-size:18px;'><strong style='color:blue;' >Target Date:</strong> ".$target_date."</p>";
													    
													    ?>
													    	<br>
												    	</div>
												    	
												    	
												    	</fieldset>
												    	<br>
												    	 <fieldset style="padding-left:15px;"><legend>User's Answer</legend>
												      <br>
												      	
												    	<div id="requirement">
												    	
													    	<label>Leave Comment:</label><br>
													    	
													    	<textarea id="myTextarea2"  name="customer_comment" rows="14" cols="65" >
													    	
													    	</textarea>
													    	
													    	<br>
												    	</div>		
													    											    
													    
													    <div id="action">
												    	
													    	<label><b style="color:red;">*</b>Customer Action: </label>
													    	<select required name="customer_action"  >
													    	<option value="">Select One</option>
													    	<option value="accept">Accept</option>
													    	<option value="discuss">Need to Discuss with Supply</option>
													    	<option value="deny">Deny</option>
													    	</select>
													    	
													    	</div>
													    	<br>
													    	
													    <br>
													    
													   </fieldset>				
												<tr>
												    <td colspan="2">
												    	<div id="button">
												    		<input type="submit" value="Submit"   name="submit" class="sub"  >  <input type="reset" value="Clear Form"   class="clear" >
												    	</div>
												    </td>
												</tr>
											</tbody>
									</table>
					              
					           </form> 
					           <?php 
					           
    	IF(isset($_POST['submit'])){
    	    
    	    // get all value
    	    $id = $_POST['ticket_id'];    	
    	    $customer_comment=$_POST['customer_comment'];
    	    $customer_action = $_POST['customer_action'];
    	   
    	    date_default_timezone_set('Asia/Hong_Kong');
    	    $reply_time = date('Y-m-d H:i:s'); 
    	   
    	    
    	    
    	    //update the db
    	    $sql4 ="UPDATE qoutation SET                   
                    customer_comment= '$customer_comment',    
                    customer_action ='$customer_action',
                       reply_date ='$reply_time'
                    WHERE id='$id'                
                    ";
    		          
    	    //execute the query
    	    $res4 = mysqli_query($conn, $sql4) or die(mysqli_error($conn)); 
    	    
    	    //redirect to manage
    	    if($res4==true){
    	        
    	        $_SESSION['reply'] ="<div class='success'> The Ticket has been replied successfully. </div>";
    	        header('location:'.SITEURL.'Adsmart_customers_quotation_status.php');
    	    }else{
    	        
    	        $_SESSION['reply'] ="<div class='error'> Failed to reply the ticket. </div>";
    	        header('location:'.SITEURL.'Adsmart_customers_quotation_status.php');
    	        
    	    }
    	    
    	    
    		          
    	}
    	
    	
    	?>
						</div>
						
		
</div>
</div>

</div>
	


<!--------------------- footer -------------->
 <?php  include('../partials-front/footer.php');?>