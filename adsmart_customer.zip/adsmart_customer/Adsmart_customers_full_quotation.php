 <?php  include('../partials-front/after_customer_login_menu.php');?>
<div style="background:#1b0075">
               <?php  include('../partials-front/customer_left_bar.php');?>


              <div class='container-fluid'>
            	   	<div class='reg' style='width: 1000px; margin-top:100px;'>
		<div class="reg">		
		
		<h1>Full Request Inforamtion</h1>   
    		
    		<div class="reg-container">	
					          <form action="handle_customer_receive_quotation.php" method="POST" enctype="multipart/form-data">
					            <table >
											<tbody>
												<tr>
												     <tH colspan="2" style="text-align:center; background:#9198e5">Advertisement Request Detail</th>
												</tr>
												<tr>
												    <td colspan="2" >
												    
												    <?php 
												            $id=$_GET['id'];
												           
													    	$sql1 = "SELECT *, a.id as req_no,
                                                             case budget 
                                                                WHEN 1 Then 'Less Than \$HK 5000'
                                                                WHEN 2 Then 'Less Than \$HK 10000'
                                                                WHEN 3 Then 'Great Than \$HK 10000 and Less Than \$HK 50000'
                                                                WHEN 4 Then 'Great Than \$HK 50000 and Less Than \$HK 200000'
                                                                WHEN 5 Then 'No Budget Limited'
                                                                End as budget_name
                                                             from qoutation as a 
                                                            inner join adsmart_customer as b on a.customer_name=b.user_id
                                                            where a.id = '$id'";
													    	$res1 = mysqli_query($conn, $sql1);
													    	$row = mysqli_fetch_array($res1);
													    	$id = $row['req_no'];
													    	$customer_name =$row['customer_name'];
													    	$email = $row['email'];
													    	$requiremnt =$row['requirement'];
													    	$budget= $row['budget_name'];
													    	$deadline_date = $row['deadline_date'];
													    	$type_id = $row['category_id'];
													       $company_name = $row['company_name'];
													          $company_country = $row['company_country'];
													          $department_name =$row['department_name'];
													          $title =$row['title'];
													          $work_number = $row['work_number'];
													          $subject =$row['subject'];
													   $sql2 = "SELECT *
                                                             from adsmart_category where id = '$type_id'";
													   $res2 = mysqli_query($conn, $sql2);
													   $row2 = mysqli_fetch_array($res2);
													   $type =$row2['display_name'];
													   $category_name =$row2['category_name'];
													   ?> 	
													    	
													   <fieldset style="padding-left:15px;"><legend>Requetor's basic information</legend>
												      <br>
												      	
												    	<div id="customer_name">
												    	
													    	<label>Customer Name: </label>
													    	
													    	
													    <?php 
													    echo "<input type='text' value='".$customer_name."' name='customer_name' readonly style='color:Green; font-size: 16px; width:450px;height:30px; font-weight:bold; border: 2px solid black;'>";
													   
													    	 
													    	
													    	?>
													    	
													  
													    	
													    	<br>
													    
													    </div>		
													    											    
													    
													    <div id="email">
												    	
													    	<label>Email: </label>
													    	
													    	<?php 
													    	echo "<input type='text' value='".$email."' name='email' readonly style='color:Green; font-size: 16px; width:450px;height:30px; font-weight:bold; border: 2px solid black;'>";
													    	
													    	
													    	?>
													    	
													    	
													    	<br>
													    	
													    <br>
													    
													   </fieldset>
													   <br>
													    <fieldset style="padding-left:15px;"><legend>Ticket's information</legend>
												      <br>
												      <div id="ticket_id">
												    	
													    	<label>Ticket ID: </label>
													    	
													    <?php 
													    echo "<input type='text' value='".$id."' name='ticket_id' readonly style=' color:Green; font-size: 16px; width:450px;height:30px; font-weight:bold;border: 2px solid black;'>";
													    
													    
													    
													    ?>
													    	
													    	
													    	
													  
													    	
													    	<br>
													    
													    </div>	
													    <div id="subject">
												    	
													    	<label>Subject: </label>
													    	
													    <?php 
													    echo "<input type='text' value='".$subject."' name='subject' readonly style=' color:Green; font-size: 16px; width:450px;height:30px; font-weight:bold;border: 2px solid black;'>";
													    
													    
													    
													    ?>
													    	
													    	
													    	
													  
													    	
													    	<br>
													    
													    </div>	
													    <div id="type">
												    	
													    	<label>Advertisement Type: </label>
													    	
													    <?php 
													    echo "<input type='text' value='".$type."' name='type' readonly style=' color:Green; font-size: 16px; width:450px;height:30px; font-weight:bold;border: 2px solid black;'>";
													    
													    
													    
													    ?>
													    	
													    	
													    	
													  
													    	
													    	<br>
													    
													    </div>	
												      <div id="req">
												    	
													    	<label>Requirement: </label> <br>
													    	
													    <?php 
													    echo " <textarea required id='requirement'  name='requirement'rows='14' cols='65' readonly>";
													    echo $requiremnt;
													    echo	"</textarea>";
                                                        
													    
													    
													    ?>
													    	
													    	
													    	
													  
													    	
													    	<br>
													    
													    </div>		
												    	<div id="budget">
												    	
													    	<label>Budget: </label>
													    	
													    	
													    <?php 
													    echo "<input type='text' value='".$budget."' name='budget' readonly style='color:Green; font-size: 16px; width:450px;height:30px; font-weight:bold; border: 2px solid black;'>";
													   
													    	 
													    	
													    	?>
													    	
													  
													    	
													    	<br>
													    
													    </div>		
													    											    
													    
													    <div id="email">
												    	
													    	<label>Deadline Date: </label>
													    	
													    	<?php 
													    	echo "<input type='text' value='".$deadline_date."' name='deadline_date' readonly style='color:Green; font-size: 16px; width:450px;height:30px; font-weight:bold; border: 2px solid black;'>";
													    	
													    	
													    	?>
													    	
													    	
													    	<br>
													    	
													    <br>
													    </div>
													   </fieldset>
													    <br>
												    	<fieldset style="padding-left:15px;"><legend>Company's information</legend>
												    	  <br>
												    	<?php 
												    	$id=$_GET['id'];
												    	$sql3 = "SELECT *
                                                             from qoutation a
                                                             inner join adsmart_business_partner b 
                                                             on a.company_id = b.shop_code
                                                             where a.id = '$id'";
												    	$res3 = mysqli_query($conn, $sql3);
												    	$row3 = mysqli_fetch_array($res3);
												    	$account_name =$row3['user_id'];
												    	$company_name =$row3['company_name'];
												    	$company_reg_number =$row3['company_reg_number'];												    	
												    	$company_reg_address =$row3['company_reg_address'];
												    	$company_email =$row3['email'];
												    	$country = $row3['country'];
												    	$shop_code =$row3['shop_code'];
												    	$implementation= $row3['implementation_plan'];
												    	$price= $row3['company_price'];
												    	$target_date =$row3['target_date'];
												    	$company_bid_time = $row3['company_bid_time'];
												    	$customer_action =$row3['customer_action'];
												    	$customer_comment =$row3['customer_comment'];
												    	
												    	?>
												    	<div id="company_id">
												    	
													    	<label>Company ID: </label>
													    	
													    <?php 
													    echo "<input type='text' value='".$shop_code."' name='company_id' readonly style=' color:Green; font-size: 16px; width:250px;height:30px; font-weight:bold;border: 2px solid black;'>";
													    
													    
													    
													    ?>
													    	
													    	
													    	
													  
													    	
													    	<br>
													    
													    </div>		
												    	<div id="company_name">
													    	<label>Company Name: </label>
													    	
													    <?php 
													    echo "<input type='text' value='".$company_name."' name='company_name' readonly style='color:Green; font-size: 16px; width:450px;height:30px; font-weight:bold; border: 2px solid black;'>";
													   	?>
													    	<br>
													    </div>		
												    	<div id="company_email">
													    	<label>Company Email: </label>
													    	
													    <?php 
													    echo "<input type='text' value='".$company_email."' name='company_email' readonly style='color:Green; font-size: 16px; width:450px;height:30px; font-weight:bold; border: 2px solid black;'>";
													   	?>
													    	<br>
													    </div>	
													    <div id="company_reg_number">
													    	<label>Company Registration Number: </label>
													    	
													    <?php 
													    echo "<input type='text' value='".$company_reg_number."' name='company_reg_number' readonly style='color:Green; font-size: 16px; width:450px;height:30px; font-weight:bold; border: 2px solid black;'>";
													   	?>
													    	<br>
													    </div>
													    
													    <div id="company_reg_address">
													    	<label>Company Registration Address: </label>
													    	
													    <?php 
													    echo "<input type='text' value='".$company_reg_address."' name='company_reg_address' readonly style='color:Green; font-size: 16px; width:450px;height:30px; font-weight:bold; border: 2px solid black;'>";
													   	?>
													    	<br>
													    </div>			
													    <div id="company_reg_address">
													    	<label>Country: </label>
													    	
													    <?php 
													    echo "<input type='text' value='".$country."' name='country' readonly style='color:Green; font-size: 16px; width:450px;height:30px; font-weight:bold; border: 2px solid black;'>";
													   	?>
													    	<br>
													    </div>		
												    	<div id="implementation">
												    	
													    	<label>Implementation Plan:</label><br>
													    	
													    	<?php 
													    echo " <textarea required id='implementation'  name='implementation' rows='14' cols='65' readonly>";
													    echo $implementation;
													    echo	"</textarea>";
                                                        
													    
													    
													    ?>
													    	
													    	<br>
												    	</div>		
												    	<BR>
												    	
													    <div class="input-group">
													    	<label>Price</label>
													    		 <?php 
													    echo "<input type='text' value='".$price."' name='Price' readonly style='color:Green; font-size: 16px; width:450px;height:30px; font-weight:bold; border: 2px solid black;'>";
													   	?>
													    		
													    		</div>
												    	
												    	<div class="input-group">
													    	<label>Target Date:</label>
													    	 <?php 
													    echo "<input type='text' value='".$target_date."' name='Target Date' readonly style='color:Green; font-size: 16px; width:450px;height:30px; font-weight:bold; border: 2px solid black;'>";
													   	?>
													    	
												    	</div>
												    	
												    	
												    	</fieldset>
												    	<br>
												    	 <fieldset style="padding-left:15px;"><legend>User's Answer</legend>
												      <br>
												      	
												    	<div id="requirement">
												    	
													    	<label>Leave Comment:</label><br>
													    	<?php 
													    	echo "<textarea  id='customer_comment'  name='customer_comment' rows='14' cols='65' readonly>";
													    	  echo $customer_comment;
													    	echo "</textarea>";
													    	?>
													    	<br>
												    	</div>		
													    											    
													    
													    <div id="action">
												    	
													    	<label><b style="color:red;">*</b>Customer Action: </label>
													    	<?php 
													    	echo "<input type='text' value='".$customer_action."' name='customer_action' readonly style='color:Green; font-size: 16px; width:450px;height:30px; font-weight:bold; border: 2px solid black;'>";
													   	?>
													    	
													    	</div>
													    	<br>
													    	
													    <br>
													    
													   </fieldset>				
												
											</tbody>
									</table>
					              
					           </form> 
					        
						</div>
						
		
</div>
</div>
</div>

	


<!--------------------- footer -------------->
 <?php  include('../partials-front/footer.php');?>