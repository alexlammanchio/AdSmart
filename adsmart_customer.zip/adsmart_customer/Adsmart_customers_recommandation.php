

<!-- -Cart Items Details -->
<div class="small-container cart-page">
			<h2> Related Your Preferred Advertisement Types</h2>
			<div class="small-container">
				<div class="row">	
							
						<div class="col-4">
							<img src="<?php  echo IMAGES;?>/images/product-w.png">
							<h4>Macao Advertisement Company - W Company</h4>							
							<br>
							 <b>Advertisement type:	</b> <p style="color:blue;"> Outdoor Ads	<p>				
							 <a href="product-detail.html"   target="blank"> <button type="button"class="btn" style="background:#9198e5">Detail</button> </a>
						</div>
						<div class="col-4">
							<img src="<?php  echo IMAGES;?>/images/product-b.jpg">
							<h4>Macao Advertisement Company - B Company</h4>
							<br>
							 <b>Advertisement type:	</b> <p style="color:blue;"> Outdoor Ads	<p>					
							 <a href="product-detail.html"   target="blank"> <button type="button"class="btn" style="background:#9198e5">Detail</button> </a>
						</div>						
						<div class="col-4">
							<img src="<?php  echo IMAGES;?>/images/mango.jpg">
							<h4>China Advertisement Company - TV Company</h4>
							<br>
							 <b>Advertisement type:	</b> <p style="color:blue;"> Print Ads	<p>					
							 <a href="product-detail.html"   target="blank"> <button type="button"class="btn" style="background:#9198e5">Detail</button> </a>
						
						</div>	
						<div class="col-4">
							<img src="<?php  echo IMAGES;?>/images/product-w.png">
							<h4>Macao Advertisement Company - W Company</h4>							
							<br>
							 <b>Advertisement type:	</b> <p style="color:blue;"> Outdoor Ads	<p>				
							 <a href="product-detail.html"   target="blank"> <button type="button"class="btn" style="background:#9198e5">Detail</button> </a>
						</div>
						<div class="col-4">
							<img src="<?php  echo IMAGES;?>/images/product-b.jpg">
							<h4>Macao Advertisement Company - B Company</h4>
							<br>
							 <b>Advertisement type:	</b> <p style="color:blue;"> Outdoor Ads	<p>					
							 <a href="product-detail.html"   target="blank"> <button type="button"class="btn" style="background:#9198e5">Detail</button> </a>
						</div>						
						<div class="col-4">
							<img src="<?php  echo IMAGES;?>/images/mango.jpg">
							<h4>China Advertisement Company - TV Company</h4>
							<br>
							 <b>Advertisement type:	</b> <p style="color:blue;"> Print Ads	<p>					
							 <a href="product-detail.html"   target="blank"> <button type="button"class="btn" style="background:#9198e5">Detail</button> </a>
						
						</div>	
						<div class="col-4">
							<img src="<?php  echo IMAGES;?>/images/product-b.jpg">
							<h4>Macao Advertisement Company - B Company</h4>
							<br>
							 <b>Advertisement type:	</b> <p style="color:blue;"> Outdoor Ads	<p>					
							 <a href="product-detail.html"   target="blank"> <button type="button"class="btn" style="background:#9198e5">Detail</button> </a>
						</div>						
						<div class="col-4">
							<img src="<?php  echo IMAGES;?>/images/mango.jpg">
							<h4>China Advertisement Company - TV Company</h4>
							<br>
							 <b>Advertisement type:	</b> <p style="color:blue;"> Print Ads	<p>					
							 <a href="product-detail.html"   target="blank"> <button type="button"class="btn" style="background:#9198e5">Detail</button> </a>
						
						</div>
						
						<div class="row">
				<div class="ads-btn">
					<span>1</span>
					<span>2</span>
					<span>3</span>
					<span>4</span>
					<span>&#8594;</span>
				</div>		
				</div>
		</div>				
	</div>	
</div>


	


<!--------------------- footer -------------->
	