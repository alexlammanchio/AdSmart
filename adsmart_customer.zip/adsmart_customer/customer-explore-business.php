<?php  include('../partials-front/after_customer_login_menu.php');?>
    <!-- fOOD MEnu Section Starts Here -->
 
 <?php 
            
                //get the serach keyword
                $search =$_POST['search'];
              
            ?>
         <div style="background:#1b0075">
                <?php  include('../partials-front/customer_left_bar.php');?>


              <div class='container-fluid'>
            	   	<div class='reg' style='width: 1000px; margin-top:100px;'>   
            	   	<div class="reg-container">	
					          <form action="<?php echo ADSMART_CUSTOMER;?>customer-space-search.php" method="POST">
					            <table id="customer_reg">
											<tbody>
												
												<tr>
												    <td colspan="2" >												    														
												    	<div id="name">
													    	<label style="padding-left:250px; font-size:28px;">What Can I do for you?</label><br><br>
													    	<input id="input_0" type="search" name="search" placeholder="Input your Idea" style="width:850px; border: 1px solid black;height:50px; margin-left:60px;"><br>
													    </div>
													  
												    	
												    	
												<tr>
												    <td colspan="2">
												    	<div id="button">
												    		<input type="submit" value="Search" name="submit"   class="sub"  style="margin-left:350px;" > 
												    	</div>
												    </td>
												</tr>
											</tbody>
									</table>
					              
					           </form> 
						</div>
						<br>
						
              <div class="small-container" style="margin-bottom:250px;">     


<!-- single product details -->	
<?php  
		$id = $_GET['id'];
		$sql1 = "SELECT *
                 from adsmart_business_product where company_id = '$id'";
		$res1 = mysqli_query($conn, $sql1);
		$row = mysqli_fetch_array($res1);
		
		$company_name =$row['company_name'];
		
		?>
		<h1 style ="font-size:45px;"> Shop Name: <?php  echo $company_name;?></h1>
<div class="small-container single-product">
	<div class="row">
	
		<div class="col-2">
		<?php  
		$id = $_GET['id'];
		$sql1 = "SELECT *
                 from adsmart_business_product where company_id = '$id'";
		$res1 = mysqli_query($conn, $sql1);
	
		$count =mysqli_num_rows($res1);
		if($count>0){
		    ?>
		    <img src="<?php  echo IMAGES;?>/images/business_product/<?php  echo $row['image_name']?>"  width='500px' height='350px'  id='ProductImg'>
		    <?php 
		   echo "<div class='small-img-row'>";
		    while($row = mysqli_fetch_array($res1) ){
		        
		      $product_name =$row['product_category_name'];
		        
		 		
				echo "<div class='small-img-col'>";
				?>
					<img src="<?php  echo IMAGES;?>/images/business_product/<?php  echo $row['image_name']?>" width="150px" height="150px" class="small-img">
				
				
			
			   <?php 
			   echo "</div>";
			    
			   
			   ?>
		    <?php    
		    }
		    echo "</div>";
		}
		
		?>
			
			
		</div>
		<div class="col-2">
			  <form action="handle_add_shopping_cart.php" method="post">
			
			<?php 
            				          
            				          
            				          
			$sql2 = "SELECT *
                 from adsmart_business_product where company_id = '$id'";
			$res2 = mysqli_query($conn, $sql2);
			
			echo "<h1 style='font-size:40px;'><B>Product Name: </b>".$product_name."</h1>";
			
			    
            				          echo "<select id='product' name='product_name' onchange='updatePrice()'  style='border: 1px solid black; margin-left:115px; '>";   
            				          echo "<option value=''>Select One</option>";
            				          while($row = mysqli_fetch_array($res2) ){
            				              $product_name = $row['product_name'];
            				              $description = $row['description'];
            				              $price = $row['price'];
            				              $company_name =$row['company_name'];
            				              $company_id =$row['company_id'];
            				              echo "<option value='".$product_name."' data-price='".$price."'data-desc='".$description."'>".$product_name."</option>";
            				          }
            				          
            				          echo "</select>";
            				         echo  "<br>";
            				         echo "<p style='color:Green; font-size:20px;margin-left:-180px;'><b>Price:</b></p><br>";
            				         echo "<div style ='width: 150px; height:50px; margin-left:115px; border: 2px solid black; text-align:left; padding:10px 10px;'>";
            				        echo "$<span id='price' name='price' ></span>";
            				       
            				        echo "</div><br>";
            				        echo "<label style='color:Green; font-size:20px;margin-left:-40px;'><b>Quantity:</label>";            				        
            				         echo  "<input type='number' name='quantity' value='1'min='1' style='width:100px; border: 2px solid black;'>";
            				         echo "<br>";
            				         echo "<br>";
            				         echo "<p style='color:Green; font-size:20px;margin-left:-120px;'><b>Description:</b></p><br>";
            				        echo "<div style ='width: 400px; height:200px; margin-left:115px; border: 2px solid black; text-align:left; padding:10px 10px;'>";
            				         echo "<span id='desc' name='desc'>Please select Item</span>";
            				         echo "</div>";
            				         
            				         echo "<input type='hidden' name='company_name' value=".$company_name.">";
            				         echo  "<input type='hidden' name='company_id' value=".$company_id.">";
            				         echo "<input type='hidden' name='customer_name' value=".$account_name.">";
            				         echo "<input type='hidden' id='hiddenPrice' name='price' value=''>";
            				         
            				         echo  "<input type='submit' value='Add to Cart'   name='submit' class='btn'  style= 'font-size:20px;background: Red; width:400px;margin-left:115px;'>";?>
            				         <a href='<?php echo SITEURL; ?>Adsmart_customers_send_requirement.php?company_id=<?php echo $id;?>' class='btn' style= 'font-size:20px;background: blue;height:40px;width:400px;margin-left:115px;'> Send A Requiremnt</a>
            				        
			
			</form>
		</div>
	</div>
</div>


<!-- ----- products -->

		
<div class="small-container">		
					<div class="row row-2">
						<h2> Related Supplier</h2>
						<p> View more</p>	
					
					</div>	
				
				<div class="row">	
							
						<div class="col-4">
							<img src="<?php echo IMAGES;?>/images/product-w.png">
							<h4>Macao Advertisement Company - W Company</h4>
							<br>
							 <b>Description:	</b> <p style="color:blue;">  Macau Advertisement company. We can Provide Bus Stop Advertisement Panel Service.	<p>				
							 <a href="product-detail.php"   target="blank"> <button type="button"class="btn" style="background:#9198e5">Detail</button> </a>
						</div>
						<div class="col-4">
							<img src="<?php echo IMAGES;?>/images/product-b.jpg">
							<h4>Macao Advertisement Company - B Company</h4>
							<br>
							 <b>Description:	</b> <p style="color:blue;">  Macau Advertisement company. We can provide full-advertisement services to our customers that it includes digital advertisement.	<p>				
							 <a href="product-detail.php"   target="blank"> <button type="button"class="btn" style="background:#9198e5">Detail</button> </a>
						</div>						
						<div class="col-4">
							<img src="<?php echo IMAGES;?>/images/mango.jpg">
							<h4>China Advertisement Company - TV Company</h4>
							<br>
							 <b>Description:	</b> <p style="color:blue;">  Chinese Advertisement Company. We can provide TV Adverisement Service in China. 	<p>				
							 <a href="product-detail.php"   target="blank"> <button type="button"class="btn" style="background:#9198e5">Detail</button> </a>
						
						</div>	
						</div>		
				
</div>
</div>

</div>
</div>


<!--  JS for product gallery-->	
	<script>
		var ProductImg = document.getElementById("ProductImg");
		var SmallImg = document.getElementsByClassName("small-img");
		SmallImg[0].onclick = function(){
			ProductImg.src = SmallImg[0].src;
			
		}
		SmallImg[1].onclick = function(){
			ProductImg.src = SmallImg[1].src;
		
	}
		SmallImg[2].onclick = function(){
			ProductImg.src = SmallImg[2].src;
		
	}
		SmallImg[3].onclick = function(){
			ProductImg.src = SmallImg[3].src;
		
	}

		function updatePrice() {
            var selectElement = document.getElementById("product");
            var selectedOption = selectElement.options[selectElement.selectedIndex];
            var price = selectedOption.getAttribute("data-price");
            var desc = selectedOption.getAttribute("data-desc");
            
            
            document.getElementById("price").textContent = price;
            document.getElementById("price").setAttribute("data-value", price);
            document.getElementById("hiddenPrice").value = price;
            document.getElementById("desc").textContent = desc;
            
        }
	</script>
<!--------------------- footer -------------->
 <?php  include('../partials-front/footer.php');?>