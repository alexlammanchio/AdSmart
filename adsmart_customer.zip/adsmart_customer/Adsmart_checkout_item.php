

<!-- -Cart Items Details -->
<div class="small-container cart-page" style ="padding-bottom:300px;">
		
		<div class="reg">
		<h1>Order Status</h1>             
           <table style="width:100%">
				  <tr>
				    <th>Subject</th>
				    <th>Advertisement Business partner name</th>				    
				    <th> Targeted Date</th>
				   <th>Detail</th>
				  </tr
				  >
				  <tr>
				   <td>PO123667</td>
				    <td>ABC advertiser</td>				   
				    <td> 2023-05-15</td>
				    <td> <button type="button"  class="btn" style="background:Red;"> Expired </button></td>
				  </tr>
				  <tr>
				    <td>PO123456</td>
				    <td>CCCC provider</td>				    
				    <td>2024-06-30</td>
				    <td> <button type="button"  class="btn" style="background:#9198e5;"> Checkout </button></td>
				  </tr>
				  <tr>
				    <td>PO123456</td>
				    <td>CCCC provider</td>
				    
				    <td>2024-06-30</td>
				    <td> <button type="button"  class="btn" style="background:#9198e5;"> Checkout </button></td>
				  </tr>
				  
			</table>
			<div class="row">
				<div class="ads-btn">
					<span>1</span>
					<span>2</span>
					<span>3</span>
					<span>4</span>
					<span>&#8594;</span>
				</div>		
				</div>
		</div>
		
</div>


	


<!--------------------- footer -------------->
	