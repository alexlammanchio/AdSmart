

<!-- -Cart Items Details -->
<div class='small-container cart-page'>
	   	<div class='reg'>
			<h1>Advetisement Quotation Status </h1>
    			<br>
    		
    			<?php 
    			if(isset($_SESSION['create']))
    			{
    			    
    			    echo $_SESSION['create'];
    			    unset($_SESSION['create']); //removing seesion
    			}
    			if(isset($_SESSION['reply']))
    			{
    			    
    			    echo $_SESSION['reply'];
    			    unset($_SESSION['reply']); //removing seesion
    			}
    			if(isset($_SESSION['delete'])){
    			    
    			    echo $_SESSION['delete'];
    			    unset($_SESSION['delete']);
    			}
    			if(isset($_SESSION['update'])){
    			    
    			    echo $_SESSION['update'];
    			    unset($_SESSION['update']);
    			}
    			if(isset($_SESSION['user-not-found'])){
    			    
    			    echo $_SESSION['user-not-found'];
    			    unset($_SESSION['user-not-found']);
    			}
    			if(isset($_SESSION['pwd-not-match'])){
    			    
    			    echo $_SESSION['pwd-not-match'];
    			    unset($_SESSION['pwd-not-match']);
    			}
    			if(isset($_SESSION['change-pwd'])){
    			    
    			    echo $_SESSION['change-pwd'];
    			    unset($_SESSION['change-pwd']);
    			}
    			?>
    			<br>
    			<br>    		
    			<table class="tbl-full">
    				<tr>
    					<th>NO.</th>
    					<th>Request Number</th>    					
    					<th>Subject / Product Name</th>
    					<th>Budget</th>
    					<th>Deadline Date</th>
    					<th>Company Name</th>
    					<th>Status</th>
    				</tr>
    				
    				<?php 
    				    //select all admin
    				$session_id =$_SESSION['user1'];
    				    $sql ="SELECT a.*,  c.user_id, 
                                case a.budget 
                                WHEN 1 Then 'Less Than \$HK 5000'
                                WHEN 2 Then 'Less Than \$HK 10000'
                                WHEN 3 Then 'Great Than \$HK 10000 and Less Than \$HK 50000'
                                WHEN 4 Then 'Great Than \$HK 50000 and Less Than \$HK 200000'
                                WHEN 5 Then 'No Budget Limited'
                                End as budget_name
                                FROM qoutation a                                
                                INNER JOIN adsmart_customer c ON a.customer_id = c.id 
                                Where c.user_id ='$session_id' 
                                order by a.deadline_date asc";
    				//execute the query
    				    $res = mysqli_query($conn, $sql);
    				    
    				    //check wether the query is executed or not
    				    if($res==TRUE){
    				        
    				        $count =mysqli_num_rows($res); //function to get all the rows 
    				        
    				        $sn=1;
    				        
    				        
    				        if($count>0){
    				            
    				            
    				            while($rows=mysqli_fetch_assoc($res))
    				            {
    				            
    				            //using while loop to get all the data from db
    				            // and while loop will run as long as we have data in db
    				            // get individual data
    				                $quotation_id=$rows['id']; 
    				                $req_number=$rows['req_number'];    				                
    				                $subject=$rows['subject'];
    				                $deadline_date=$rows['deadline_date'];
    				                $company_name =$rows['company_name'];
    				                $budget=$rows['budget_name'];
    				                $customer_action = $rows['customer_action'];
    				                $company_reject_msg =$rows['company_reject_msg'];
    				                $company_id =$rows['company_id'];
    				                $product_name =$rows['product_name'];
    				                ?>
    				                <tr>
                    					<td><?php echo $sn++; ?></td>
                    					<td><?php echo $req_number; ?></td>
                    					
                    					<td><?php if($subject != ''){
                                            echo $subject;

                    					}else{
                    					    echo $product_name;
                    					    
                    					}; ?></td>
                    					<td><?php echo $budget; ?></td>
                    					<td><?php echo $deadline_date;   ?></td>
                    					<td><?php if($company_name !=""){echo $company_name;}else{echo "N/A";} ?></td>
                    					<td>
                    					<?php 
                    					
                    					
                    					$dt = date('Y-m-d');
                    					
                    					if($deadline_date < $dt){ 
                    					    echo "<a href='";
                    					    echo ADSMART_CUSTOMER; echo "Adsmart_customers_expired_quotation.php?id=";
                    					    echo $quotation_id; 
                    					echo "' class='btn-backend-3' >Expired! </a>";
                    					
                    					}elseif($company_reject_msg !=""){ echo "<a class='btn-backend-3' >Rejected! </a>";}
                    					
                    					elseif($company_id !='0' && $customer_action == 'accept' && $customer_action !="" ){
                    					    echo "<a href='";
                    					    echo ADSMART_CUSTOMER; echo "Adsmart_customers_full_quotation.php?id=";
                    					    echo $quotation_id; echo "' class='btn-backend-1'>Waiting for Company to review</a>";
                    					    
                    					    
                    					}
                    					elseif($company_id !='0' && $customer_action == 'discuss' && $customer_action !="" ){
                    					    echo "<a href='";
                    					    echo ADSMART_CUSTOMER; echo "Adsmart_customers_discuss_quotation.php?qoutation_id=";
                    					    echo $quotation_id; echo "' class='btn-backend-1'>Discuss With Supplier</a>";
                    					    
                    					    
                    					}elseif($company_id !='0' && $customer_action == 'deny'){
                    					    echo "<a href='";
                    					    echo ADSMART_CUSTOMER; echo "Adsmart_customers_full_quotation.php?id=";
                    					    echo $quotation_id; echo "' class='btn-backend-3'>Rejected the quotation</a>"; 
                    					    
                    					    
                    					}
                    					
                    					elseif($company_id !='0' && $company_name !='' ){ echo "<a href='"; 
                    					echo ADSMART_CUSTOMER; echo "Adsmart_customers_receive_quotation.php?id="; 
                    					echo $quotation_id; echo "' class='btn-backend-2'>Received the quotation</a>"; 
                    					}elseif($company_name !='' && $product_name != ''){
                    					    echo "<a href='";
                    					    echo ADSMART_CUSTOMER; echo "Adsmart_customers_after_send_requirement.php?id=";
                    					    echo $quotation_id;
                    					    
                    					    echo "'class='btn-backend-1'>Waiting for Company to review </a>";
                    					    
                    					}
                    					
                    					
                    					else{ echo "<a href='";
                    					echo ADSMART_CUSTOMER; echo "Adsmart_customers_after_create_quotation.php?id=";
                    					echo $quotation_id; 
                    					    
                    					    echo "'class='btn-backend-1'>Waiting for Company to bid </a>"; } ?>
                    					</td>
                					</tr>
                				                
    				                <?php 
    				                
    				             }
    				        }
    				        else 
    				        {
    				            // we do not have data indb
    				        }
    				    }
    				?>    				
    				
    				
    				
    			</table>
    			<br>
			</div>
		</div>


	


<!--------------------- footer -------------->
