<?php

session_start();

if(isset($_SESSION['user2']) && isset($_SESSION['shopcode'])){
    include '../partials-front/after_company_login_menu.php';
}
elseif (isset($_SESSION['user1'])){
    include '../partials-front/after_customer_login_menu.php';
}else {include '../partials-front/menu.php';}


?>
 
 <!-- AdSmart  header  --> 

<!-- -Cart Items Details -->
<div class="small-container cart-page">
		<h1 style="text-align:center; font-size:40px; ">Shopping Cart</h1>
		<br>
		<form>
		<table>
			<tr>
					 <th>Item Number</th>
				    <th>Company Name</th>
				    <th>Product Name</th>
				    <th>Product Image</th>
				    <th>Price & Quantity</th>
				    <th>Total Amount</th>
			</tr>
			<?php 
			$sql2 = "SELECT *, a.quantity as shopp_cart_quantity, a.price*a.quantity  as total_amount   from shopping_cart a join adsmart_business_product b on a.company_id = b.company_id and a.product_name = b.product_name";
			$res2 = mysqli_query($conn, $sql2);
			
			if($res2==TRUE){
			    
			    $count =mysqli_num_rows($res2); //function to get all the rows
			    
			    $sn=1;
			    
			    
			    if($count>0){
			        $totalAmount = 0; 
			        
			        while($rows=mysqli_fetch_assoc($res2))
			        {
			            
			                 $company_name = $rows['company_name'];
			                 $product_name =$rows['product_name'];
			                 $image_name =$rows['image_name'];
			                 $price =$rows['price'];
			                 $quantity =$rows['shopp_cart_quantity'];
			                 $total_amount = $rows['total_amount'];
			                 $totalAmount += $total_amount;
			            ?>
			            <tr>
			            <td><?php echo $sn++; ?></td>
                    					<td><?php echo $company_name; ?></td>
                    					<td><?php echo $product_name; ?></td>
                    					
                    					<td><?php 
                    					echo "<div class='cart-info'>";
                    					echo "<img src='../images/business_product/".$image_name."'>"; 
                    					echo "</div>";
                    					?>
                    					
                    					
                    					</td>
                    					<td><?php 
                    					echo "<b>Price:</b>".$price;
                    					echo "<input type='number' value='".$quantity."' onchange='updateTotal(2, this.value)'>";
                    					?>
                               			 </td>
                               			 <td>
                    					 <?php echo $total_amount; ?>
                    					<br><a href=''> Remove </a>
                    					
                    					</td>
                    	</tr>
                    	<?php 
			        }
			       
			       
			    }else
			    {
			        // we do not have data indb
			    }
			}
			
			?>
			
				<tr>
					<td style=" border-right: none;"></td>
					<td style=" border-right: none;"></td>
					<td style=" border-right: none;"></td>
					<td></td>
					<td >Subtotal</td>
					<td><?php echo $totalAmount;?> </td>				
				
				</tr>
				<tr>
					<td style=" border-right: none;"></td>
					<td style=" border-right: none;"></td>
					<td style=" border-right: none;"></td>
					<td></td>
					<td>AdSmart Service Charge (10%)</td>
					<td><?php echo "+".$totalAmount*0.1;?> </td>				
				
				</tr>
				<tr>
					<td style=" border-right: none;"></td>
					<td style=" border-right: none;"></td>
					<td style=" border-right: none;"></td>
					<td></td>
					<td>Tax (0.5%)</td>
					<td><?php echo "+".$totalAmount*0.9*0.05;?></td>				
				
				</tr>
				<tr>
					<td style=" border-right: none;"></td>
					<td style=" border-right: none;"></td>
					<td style=" border-right: none;"></td>
					<td></td>
					<td>Total</td>
					<td><?php echo $totalAmount+$totalAmount*0.1+$totalAmount*0.9*0.05;?> </td>				
				
				</tr>
			</table>
		<div id="checkout" style="text-align:center;">	
		  <a href="checkout.php"    target="blank"> <button type="button" class="btn"  style="font-size:16px; font-weight:bold; height:50px;width:80%; ">Checkout</button> </a>
		 </div>
		</form> 
</div>

<script>
  function updateTotal(productId, quantity) {
    var priceElement = document.getElementById("price_" + productId);
    var price = parseFloat(priceElement.textContent);
    var total = price * quantity;
    document.getElementById("total_" + productId).textContent = total.toFixed(2);

    var totalAmount = 0;
    var totalElements = document.querySelectorAll("td[id^='total_']");
    for (var i = 0; i < totalElements.length; i++) {
      totalAmount += parseFloat(totalElements[i].textContent);
    }
    document.getElementById("totalAmount").textContent = totalAmount.toFixed(2);
  }
</script>

	


<!--------------------- footer -------------->
<?php  include('../partials-front/footer.php');?>