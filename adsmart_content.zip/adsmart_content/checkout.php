<?php

session_start();

if(isset($_SESSION['user2']) && isset($_SESSION['shopcode'])){
    include '../partials-front/after_company_login_menu.php';
}
elseif (isset($_SESSION['user1'])){
    include '../partials-front/after_customer_login_menu.php';
}else {include '../partials-front/menu.php';}


?>
 
 <!-- AdSmart  header  --> 
<!-- -Cart Items Details -->
<div class="small-container cart-page">
		<h1>Online Payment</h1>
		<form>
		<div class="checkout_form">
			<div>
				<div class="total_amount">
						<p>Total Amount: $17550.00</p>
				</div>
				<div id="name">
					<label>Name On Card</label><br>
					<input id="input_0" type="text" name="name" placeholder="please input your name" style="width:250px"><br>
				</div>
				<br>
				<div id="Card_no">
					<label>Card Number</label><br>
					<input id="input_1" type="number" name="name" placeholder="please input your card number" style="width:250px"><br>
				</div>
				<br>
				<div id="CVV">
					<label>CVV</label><br>
					<input id="input_1" type="number" name="name" placeholder="please input CVV" style="width:250px"><br>
				</div>
				<br>
				<div id="CVV">
					<label>Expiration Date</label><br>
					<input type="month" id="expiry-date" name="expiry-date" min="2023-03" max="9999-12" style="width:250px" /><br>
				</div>
				<br>
			</div>
			<div>
				<img src="../images/Visa.png" width="60px" height="40px">
				<img src="../images/mastercard.png" width="60px" height="40px" style="margin-left:30px;">
			</div>
	
			
		</div>	
		</form>
		<div id="checkout" style="text-align:center;">	
		  <a href="checkout.php"    target="blank"> <button type="button" class="btn"  style="font-size:16px; font-weight:bold; height:50px;width:80%; ">Pay</button> </a>
		 </div> 
</div>


	


     <!--  Footer  -->  
     

		
     <?php  include('../partials-front/footer.php');?>