<?php  include('../partials-front/menu.php');?>
<!--  header -->
<?php 

    //Process the value from form and save it in db


 
if(isset($_POST['submit'])){

    //button clicked
    //1. Get the data from form
    $account_name = $_POST['account_name'];
    $company_name = $_POST['company_name'];
    $company_chinese_name = $_POST['company_chinese_name'];
    $company_reg_number= $_POST['company_reg_number'];
    $company_reg_address = $_POST['company_reg_address'];
    $description = $_POST['description'];    
    $country = $_POST['country']; 
    $email= $_POST['email'];
    $password = md5($_POST['password']);  
    $password_confirm = md5($_POST['password_confirm']); 
    $phonecode =$_POST['phonecode'];
   
    
    $contact_number =$_POST['contact_number'];
    $_SESSION['contact_number'] = $_POST['contact_number'];
    
    $mobile_number = $phonecode.$contact_number;
    
    $contact_number =$_POST['contact_number'];
    $_SESSION['contact_number'] = $_POST['contact_number'];
    // 定義不允許字元
    $specialChars = "!@#$%^&*()/\\\'\"";
    
    if(strpbrk($contact_number, $specialChars) !== false) {
        // special char found
        $_SESSION['special_character4'] = "<div style='color:red; font-size:14px;'> Contact Number just accept Hyphen - and Plus sign + special characters And Space. </div>";
        header('location:'.SITEURL.'Adsmart_partners_registration.php');
        die();
    }
    
    //updating new image if selected
    if(isset($_FILES['image']['name'])){
        //upload the image
        $image_name=$_FILES['image']['name'];
        
        //Upload the image only if image is selected
        if($image_name !="")
        {
            
            
            //Auto Rename our image
            //Get the extension of our image(jpg,png) e.g "special.jpg"
            
            $ext =end(explode('.', $image_name));
            
            //Rename the Image
            $image_name ="AdSmart_business".rand(000,999).'.'.$ext; // food_category_834
            
            
            $source_path=$_FILES['image']['tmp_name'];
            
            $destination_path ="../images/company/".$image_name;
            
            //finally upload the image
            $upload = move_uploaded_file($source_path, $destination_path);
            
            //check whether the image is uploaded or not
            // and if the image is not uploaded then we will stop the process and redirect with error message
            if($upload==false){
                
                //Set message
                $_SESSION['upload'] = "<div class='error'> Failed to Upload image. <div>";
                header('location:'.SITEURL.'Adsmart_partners_registration.php');
                die();
            }
            
        }
    }else{
        //don't upload image and set the image_name values as blank
        $image_name="";
        
    }
    
    
   if(isset($_POST['print_ads'])){
        $print_ads = $_POST['print_ads'];
        
    }else{
        
        $print_ads = '0';
        
    }
    if(isset($_POST['outdoor_ads'])){
        $outdoor_ads = $_POST['outdoor_ads'];
        
    }else{
        
        $outdoor_ads = '0';
        
    }
    if(isset($_POST['broadcast_ads'])){
        $broadcast_ads = $_POST['broadcast_ads'];
        
    }else{
        
        $broadcast_ads = '0';
        
    }
    if(isset($_POST['telemarketing_ads'])){
        $telemarketing_ads = $_POST['telemarketing_ads'];
        
    }else{
        
        $telemarketing_ads = '0';
        
    }
    if(isset($_POST['events_ads'])){
        $events_ads = $_POST['events_ads'];
        
    }else{
        
        $events_ads = '0';
        
    }
    if(isset($_POST['placement_ads'])){
        $placement_ads = $_POST['placement_ads'];
        
    }else{
        
        $placement_ads = '0';
        
    }
    if(isset($_POST['display_ads'])){
        $display_ads = $_POST['display_ads'];
        
    }else{
        
        $display_ads = '0';
        
    }
    if(isset($_POST['search_ads'])){
        $search_ads = $_POST['search_ads'];
        
    }else{
        
        $search_ads = '0';
        
    }
    if(isset($_POST['social_ads'])){
        $social_ads = $_POST['social_ads'];
        
    }else{
        
        $social_ads = '0';
        
    }
    if(isset($_POST['video_ads'])){
        $video_ads = $_POST['video_ads'];
        
    }else{
        
        $video_ads = '0';
        
    }
    if(isset($_POST['native_ads'])){
        $native_ads = $_POST['native_ads'];
        
    }else{
        
        $native_ads = '0';
        
    }
    if(isset($_POST['influencer_ads'])){
        $influencer_ads = $_POST['influencer_ads'];
        
    }else{
        
        $influencer_ads = '0';
        
    }
    if(isset($_POST['tnc'])){
        $tnc = $_POST['tnc'];
        
    }else{
        
        $tnc = '0';
        
    }
    
    
    //Password encryption with md5
    
    //2. SQL query to save the data into db
    $sql = "INSERT INTO adsmart_business_partner SET
            user_id ='$account_name',
            company_name ='$company_name',
            company_chinese_name ='$company_chinese_name',
            company_reg_number ='$company_reg_number',
            company_reg_address ='$company_reg_address',
            contact_number ='$mobile_number',
            description = '$description',           
            country ='$country',
            email= '$email',
            password= '$password',
            password_confirm ='$password_confirm',
            print_ads= '$print_ads',
            outdoor_ads= '$outdoor_ads',
            broadcast_ads= '$broadcast_ads',
            telemarketing_ads= '$telemarketing_ads',
           events_ads ='$events_ads',
            placement_ads= '$placement_ads',
            display_ads= '$display_ads',
            search_ads ='$search_ads',
            social_ads= '$social_ads',
            video_ads= '$video_ads',
            native_ads= '$native_ads',
            influencer_ads= '$influencer_ads',
            tnc = '$tnc',
                 image_name='$image_name'
             ";
					
   
    
    
    //3. executing query and saving data into db
    $res = mysqli_query($conn, $sql) or die(mysqli_error());
    
    //4. check whether the(Query is executed) data is inseted or not and display appropriate message
    if($res==TRUE)
    {
        //Data inseted
        //echo "Data inseted";
        //create a session variable to dispaly message
        echo "Submit AdSmart Business Partner Account Successfully. ";
        //Redirect Page
       
        
    }else {
        
       // echo "fail to insert data";
        //create a session variable to dispaly message
       echo "Failed to submit AdSmart Business Partner Account.";
        //Redirect Page
        
    }
}

echo "
<div class='small-container cart-page'>
<div class='reg' >
<h2>AdSmart Business Partner Signup</h2>
<br>
<h1> $company_name</h1>
<br>

<h3 style='color:red;'>Your AdSmart Business Partner account has been applied Successfully!!!</h3>
<br>
<br>
<p> AdSmart will process your apply as soon as possible. Please check your email after three working days.<p>
<br>
<p>If you don't receive any email sent by AdSmart. Please Send the email to this enmail address adsmart@gmail.com ! </p>
<br>
<p> Click this Here to <a href='index.php' style='color:blue;'>home page! </a>.
</div>
</div>
"


?>
<!--------------------- footer -------------->
 <?php  include('../partials-front/footer.php');?>