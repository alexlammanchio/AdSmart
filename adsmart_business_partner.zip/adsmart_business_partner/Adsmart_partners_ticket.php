
<!-- -Cart Items Details -->
<div class="small-container cart-page" style ='padding-bottom:300px;'>
		
		
		 
		<div class="reg">
		<h1>Ticket Status</h1>             
           <table style="width:100%">
				  <tr>
				    <th>Order Number</th>
				    <th>Customer Name</th>
				    <th>Task Name</th>
				    <th>Status</th>
				    <th> Targeted Date</th>
				   <th>Option</th>
				  </tr>
				  <tr>
				    <td>RO123456</td>
				    <td>Alexlam</td>
					<td>create facebook page </td>
				    <td style="color:green;">In progress</td>
				    <td>2023-10-30</td>
				    <td> <button type="button"  class="btn" style="background:#9198e5;"> Update </button></td>
				  </tr>
				  <tr>
				   <td>RO555666</td>
				    <td>Cafe Cafe Coffee</td>
				    <td>Create a video promotion </td>
				    <td > Completed</td>
				    <td> 2023-06-15</td>
				    <td> <button type="button"  class="btn" style="background:#9198e5;"> View </button></td>
				  </tr>
				   <tr>
				   <td>PO123667</td>
				    <td>ABC advertiser</td>
				    <td>Create a digital promotion </td>
				    <td style="color:red;">Uncompleted</td>
				    <td> 2023-05-15</td>
				    <td> <button type="button"  class="btn" style="background:Red;"> Refund </button></td>
				  </tr>
			</table>
		</div>
	
 <div class="row">
				<div class="ads-btn">
					<span>1</span>
					<span>2</span>
					<span>3</span>
					<span>4</span>
					<span>&#8594;</span>
				</div>		
				</div>
</div>
	


<!--------------------- footer -------------->
