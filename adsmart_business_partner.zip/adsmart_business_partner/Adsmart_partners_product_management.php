
<!-- -Cart Items Details -->
<div class="small-container cart-page" style ='padding-bottom:300px;'>
		<div class="reg">
		<h1>Product Management</h1>             
           <table style="width:100%">
				 <tr>
				  <th>Number</th>
				    <th>Product Name</th>
				    <th>Product Image</th>
				    <th>Advertisement Type</th>
				    <th>Description </th>
				    <th>Price</th>
				    <th>Featured</th>
				    <th>Active</th>
				   <th>Action</th>
				  
				  </tr>
				
				 <tr>
				 <td>1 </td>
				    <td>Outdoor advertisement position - location 1</td>
				    <td><img src="<?php echo IMAGES;?>/images/bus-1.png" witdh:100px;></td>
				    <td> Outdoor Ads</td>
				    <td> Address: Macao No. 20 ABC Street - bus stop </td>
				    <td>$ 1500</td>
				    <td> Yes</td>
				    <td>Yes</td>
				     <td> <button type="button"  class="btn" style="background:#9198e5;"> Update </button>
				     <button type="button"  class="btn" style="background:red;"> Delete </button></td>
				  </tr>
				  
				  <tr>
				   	  <td>2 </td>
				    <td>Outdoor advertisement position - location 2</td>
				    <td><img src="../images/bus-2.png" witdh:100px;></td>
				    <td> Outdoor Ads</td>
				    <td> Address: Macao No. 88 DFE Street - bus stop </td>
				    <td>$ 2500</td>
				    <td> Yes</td>
				    <td>No</td>
				    <td> <button type="button"  class="btn" style="background:#9198e5;"> Update </button>
				     <button type="button"  class="btn" style="background:red;"> Delete </button></td>
				  </tr>			 
				   
			</table>
			<a href="add_partners_products.php" class="btn" style="background:#9198e5; width:80%; height:50px;font-size:25px;">Create New Products</a>
		</div>
		
</div>


	


<!--------------------- footer -------------->
	