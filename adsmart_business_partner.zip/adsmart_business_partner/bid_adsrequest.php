<?php  include('../partials-front/menu.php');?>
<!--  header -->
<?php 

    //Process the value from form and save it in db


 
if($_SERVER["REQUEST_METHOD"]=="POST"){    
    
   
    
    $implementation =$_POST['implementation'];
    $_SESSION['implementation'] = $_POST['implementation'];
   
    // 定義不允許字元
  
    $company_id =$_POST['company_id'];  
    $company_name =$_POST['company_name'];  
    
    $company_price =$_POST['price'];  
    
    date_default_timezone_set('Asia/Hong_Kong');
    $bid_time = date('Y-m-d H:i:s'); 
   
    $target_date = $_POST['target_date'];
    $id = $_POST['ticket_number'];
    
    //2. SQL query to save the data into db
    $sql = "Update qoutation SET
            company_id ='$company_id',
            company_name= '$company_name',
            implementation_plan= '$implementation',
            company_price= '$company_price',  
            company_bid_time ='$bid_time',         
            target_date= '$target_date'
           where req_number ='$id'
             ";
					
   
    
    
    //3. executing query and saving data into db
    $res = mysqli_query($conn, $sql) or die(mysqli_error());
    
    //4. check whether the(Query is executed) data is inseted or not and display appropriate message
    if($res==TRUE)
    {
        //Data inseted
        //echo "Data inseted";
        //create a session variable to dispaly message
        $_SESSION['create']= "<div style='color:green; font-size:28px;'>Advertisement Request has been bided.</div>";
        
        //Redirect Page
        header('location:'.ADSMART_BUSINESS.'Adsmart_partners_personal_space.php?page=3');
        
    }else {
        
       // echo "fail to insert data";
        //create a session variable to dispaly message
        $_SESSION['fail_create']= "<div style='color:red; font-size:28px;'>Failed to bid an Advertisement Request.</div>";
        header('location:'.ADSMART_BUSINESS.'Adsmart_partners_personal_space.php?page=2');
        //Redirect Page
        
    }
}





?>
<!--------------------- footer -------------->
 <?php  include('../partials-front/footer.php');?>